package com.cts.service;

import org.springframework.security.authentication.AuthenticationProvider;

public interface UserAuthenticationProvider extends AuthenticationProvider  {

}
