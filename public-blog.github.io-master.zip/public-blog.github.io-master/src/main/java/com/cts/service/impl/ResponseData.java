package com.cts.service.impl;

public class ResponseData {

}
