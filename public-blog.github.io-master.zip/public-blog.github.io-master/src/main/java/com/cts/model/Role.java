package com.cts.model;

public enum Role {
	ADMIN, USER, AUTHOR
}
